// This is the single file you'll edit to update all your portfolio content
// All your personal information, skills, experience, etc. will be defined here

export interface PortfolioData {
  // Basic Information
  basics: {
    name: string
    title: string
    description: string
    tagline: string
    image: string
    video?: string
    location: string
    email: string
    phone: string
    availableForHire: boolean
    resumeUrl?: string
  }

  // Social Media Links
  socialLinks: {
    github: string
    linkedin: string
    twitter: string
    instagram?: string
    youtube?: string
    facebook?: string
    dribbble?: string
    behance?: string
    medium?: string
    dev?: string
    website?: string
    other?: Array<{ name: string; url: string; icon: string }>
  }

  // Skills with logos and categories
  skills: Array<{
    category: string
    icon: string // Lucide icon name
    items: Array<{
      name: string
      logo?: string // Path to logo image or SVG
      proficiency?: number // 1-100
    }>
  }>

  // Work Experience
  experience: Array<{
    title: string
    company: string
    location: string
    period: string
    description: string
    achievements: string[]
    technologies: string[]
    logo?: string
  }>

  // Education
  education: Array<{
    degree: string
    institution: string
    location: string
    period: string
    description: string
    achievements: string[]
    courses: string[]
    logo?: string
  }>

  // Achievements and Awards
  achievements: Array<{
    title: string
    organization: string
    year: string
    description: string
    icon: string // Lucide icon name
    url?: string
  }>

  // Projects
  projects: Array<{
    title: string
    description: string
    image: string
    technologies: string[]
    demoUrl?: string
    sourceUrl?: string
    featured: boolean
  }>

  // Blog Posts
  blogPosts: Array<{
    id: string
    title: string
    slug: string
    excerpt: string
    content: string
    date: string
    readTime: string
    image: string
    categories: string[]
    featured: boolean
  }>

  // Photos Gallery
  photos: Array<{
    id: string
    title: string
    description?: string
    image: string
    date: string
    categories: string[]
  }>

  // Videos Gallery
  videos: Array<{
    id: string
    title: string
    description?: string
    thumbnailImage: string
    videoUrl: string
    date: string
    categories: string[]
  }>

  // Testimonials
  testimonials: Array<{
    name: string
    position: string
    company: string
    testimonial: string
    image?: string
  }>

  // Site Configuration
  siteConfig: {
    title: string
    description: string
    themeColor: string
    accentColor: string
    footerText: string
    showThemeToggle: boolean
    showScrollToTop: boolean
    blogEnabled: boolean
    galleryEnabled: boolean
    contactEnabled: boolean
  }
}

// Sample data - Replace with your own information
const portfolioData: PortfolioData = {
  basics: {
    name: "Your Name",
    title: "Full Stack Developer",
    description:
      "Passionate about creating beautiful, functional, and user-friendly applications. I specialize in building exceptional digital experiences.",
    tagline: "Eat. Sleep. Code. Repeat.",
    image: "/images/profile.jpg", // Replace with your image
    video: "/videos/coding.mp4", // Optional background video
    location: "San Francisco, CA",
    email: "your.email@example.com",
    phone: "+1 (123) 456-7890",
    availableForHire: true,
    resumeUrl: "/resume.pdf", // Link to your resume
  },

  socialLinks: {
    github: "https://github.com/yourusername",
    linkedin: "https://linkedin.com/in/yourusername",
    twitter: "https://twitter.com/yourusername",
    instagram: "https://instagram.com/yourusername",
    youtube: "https://youtube.com/c/yourusername",
    medium: "https://medium.com/@yourusername",
  },

  skills: [
    {
      category: "Frontend Development",
      icon: "Layout",
      items: [
        { name: "React", logo: "/logos/react.svg", proficiency: 95 },
        { name: "Next.js", logo: "/logos/nextjs.svg", proficiency: 90 },
        { name: "TypeScript", logo: "/logos/typescript.svg", proficiency: 85 },
        { name: "JavaScript", logo: "/logos/javascript.svg", proficiency: 95 },
        { name: "HTML5", logo: "/logos/html5.svg", proficiency: 95 },
        { name: "CSS3", logo: "/logos/css3.svg", proficiency: 90 },
        { name: "Tailwind CSS", logo: "/logos/tailwindcss.svg", proficiency: 90 },
        { name: "Material UI", logo: "/logos/materialui.svg", proficiency: 85 },
        { name: "Redux", logo: "/logos/redux.svg", proficiency: 80 },
      ],
    },
    {
      category: "Backend Development",
      icon: "Server",
      items: [
        { name: "Node.js", logo: "/logos/nodejs.svg", proficiency: 90 },
        { name: "Express", logo: "/logos/express.svg", proficiency: 85 },
        { name: "Python", logo: "/logos/python.svg", proficiency: 80 },
        { name: "Django", logo: "/logos/django.svg", proficiency: 75 },
        { name: "PHP", logo: "/logos/php.svg", proficiency: 70 },
        { name: "Laravel", logo: "/logos/laravel.svg", proficiency: 65 },
        { name: "RESTful APIs", proficiency: 90 },
        { name: "GraphQL", logo: "/logos/graphql.svg", proficiency: 80 },
      ],
    },
    {
      category: "Database Management",
      icon: "Database",
      items: [
        { name: "MySQL", logo: "/logos/mysql.svg", proficiency: 85 },
        { name: "PostgreSQL", logo: "/logos/postgresql.svg", proficiency: 80 },
        { name: "MongoDB", logo: "/logos/mongodb.svg", proficiency: 90 },
        { name: "Firebase", logo: "/logos/firebase.svg", proficiency: 85 },
        { name: "Redis", logo: "/logos/redis.svg", proficiency: 75 },
        { name: "Prisma", logo: "/logos/prisma.svg", proficiency: 85 },
        { name: "Sequelize", logo: "/logos/sequelize.svg", proficiency: 80 },
      ],
    },
    {
      category: "DevOps & Tools",
      icon: "Terminal",
      items: [
        { name: "Git", logo: "/logos/git.svg", proficiency: 90 },
        { name: "GitHub", logo: "/logos/github.svg", proficiency: 90 },
        { name: "Docker", logo: "/logos/docker.svg", proficiency: 80 },
        { name: "AWS", logo: "/logos/aws.svg", proficiency: 75 },
        { name: "Vercel", logo: "/logos/vercel.svg", proficiency: 90 },
        { name: "CI/CD", proficiency: 80 },
        { name: "Jest", logo: "/logos/jest.svg", proficiency: 85 },
        { name: "Cypress", logo: "/logos/cypress.svg", proficiency: 80 },
      ],
    },
  ],

  experience: [
    {
      title: "Senior Full Stack Developer",
      company: "Tech Innovations Inc.",
      location: "San Francisco, CA",
      period: "Jan 2022 - Present",
      description:
        "Leading the development of enterprise-level web applications using Next.js, React, and Node.js. Implementing CI/CD pipelines and mentoring junior developers.",
      achievements: [
        "Reduced application load time by 40% through performance optimizations",
        "Implemented a microservices architecture that improved scalability",
        "Led a team of 5 developers to deliver projects on time and within budget",
      ],
      technologies: ["React", "Next.js", "Node.js", "TypeScript", "AWS", "Docker"],
      logo: "/logos/company1.svg",
    },
    {
      title: "Full Stack Developer",
      company: "Digital Solutions Ltd.",
      location: "New York, NY",
      period: "Mar 2020 - Dec 2021",
      description:
        "Developed and maintained multiple client websites and web applications. Collaborated with designers and product managers to deliver high-quality solutions.",
      achievements: [
        "Built a custom e-commerce platform that increased client sales by 25%",
        "Implemented responsive designs that improved mobile user engagement by 30%",
        "Optimized database queries resulting in 50% faster data retrieval",
      ],
      technologies: ["JavaScript", "React", "Express", "MongoDB", "PostgreSQL", "Redux"],
      logo: "/logos/company2.svg",
    },
    {
      title: "Frontend Developer",
      company: "Creative Web Agency",
      location: "Boston, MA",
      period: "Jun 2018 - Feb 2020",
      description:
        "Created responsive and interactive user interfaces for various client websites. Worked closely with the design team to implement pixel-perfect designs.",
      achievements: [
        "Developed a component library that reduced development time by 20%",
        "Implemented accessibility improvements that achieved WCAG AA compliance",
        "Created interactive data visualizations for client dashboards",
      ],
      technologies: ["HTML5", "CSS3", "JavaScript", "React", "Sass", "Webpack"],
      logo: "/logos/company3.svg",
    },
  ],

  education: [
    {
      degree: "Master of Science in Computer Science",
      institution: "Stanford University",
      location: "Stanford, CA",
      period: "2016 - 2018",
      description:
        "Specialized in Artificial Intelligence and Machine Learning. Completed thesis on 'Neural Networks for Natural Language Processing'.",
      achievements: [
        "Graduated with Distinction (GPA: 3.9/4.0)",
        "Published 2 research papers in international conferences",
        "Teaching Assistant for 'Advanced Algorithms' course",
      ],
      courses: ["Advanced Algorithms", "Machine Learning", "Neural Networks", "Distributed Systems", "Cloud Computing"],
      logo: "/logos/stanford.svg",
    },
    {
      degree: "Bachelor of Science in Computer Engineering",
      institution: "Massachusetts Institute of Technology",
      location: "Cambridge, MA",
      period: "2012 - 2016",
      description:
        "Comprehensive program covering both hardware and software aspects of computing systems. Minor in Mathematics.",
      achievements: [
        "Dean's List for all semesters",
        "Recipient of the Engineering Excellence Scholarship",
        "Participated in ACM Programming Contest",
      ],
      courses: ["Data Structures", "Computer Architecture", "Operating Systems", "Database Systems", "Web Development"],
      logo: "/logos/mit.svg",
    },
  ],

  achievements: [
    {
      title: "Tech Innovation Award",
      organization: "Silicon Valley Tech Summit",
      year: "2023",
      description:
        "Recognized for developing an innovative AI-powered solution that revolutionized customer service automation.",
      icon: "Trophy",
    },
    {
      title: "Open Source Contributor",
      organization: "GitHub",
      year: "2022",
      description:
        "Contributed to several major open-source projects with over 500+ commits and 20+ merged pull requests.",
      icon: "Star",
      url: "https://github.com/yourusername",
    },
    {
      title: "Published Research Paper",
      organization: "International Journal of Computer Science",
      year: "2021",
      description:
        "Published a research paper on 'Optimizing React Applications for Performance' that received widespread recognition.",
      icon: "BookOpen",
      url: "https://example.com/paper",
    },
    {
      title: "Hackathon Winner",
      organization: "Global Code Challenge",
      year: "2020",
      description:
        "Led a team of 4 developers to win first place in a 48-hour hackathon, building a solution for remote education.",
      icon: "Award",
    },
  ],

  projects: [
    {
      title: "E-commerce Platform",
      description:
        "A full-featured e-commerce platform with product management, cart functionality, payment processing, and order tracking.",
      image: "/projects/ecommerce.jpg",
      technologies: ["Next.js", "React", "Node.js", "MongoDB", "Stripe"],
      demoUrl: "https://ecommerce-demo.example.com",
      sourceUrl: "https://github.com/yourusername/ecommerce",
      featured: true,
    },
    {
      title: "Task Management App",
      description:
        "A collaborative task management application with real-time updates, team workspaces, and progress tracking.",
      image: "/projects/taskmanager.jpg",
      technologies: ["React", "Firebase", "Material UI", "Redux"],
      demoUrl: "https://taskmanager-demo.example.com",
      sourceUrl: "https://github.com/yourusername/taskmanager",
      featured: true,
    },
    {
      title: "Weather Dashboard",
      description:
        "A weather dashboard that provides real-time weather information, forecasts, and historical data visualization.",
      image: "/projects/weather.jpg",
      technologies: ["JavaScript", "Chart.js", "Weather API", "CSS3"],
      demoUrl: "https://weather-demo.example.com",
      sourceUrl: "https://github.com/yourusername/weather",
      featured: false,
    },
  ],

  blogPosts: [
    {
      id: "1",
      title: "Building Scalable Web Applications with Next.js",
      slug: "building-scalable-web-applications",
      excerpt: "Learn how to leverage Next.js features to build applications that can handle millions of users.",
      content: `
# Building Scalable Web Applications with Next.js

Next.js has become one of the most popular frameworks for building React applications. Its server-side rendering capabilities, static site generation, and built-in API routes make it an excellent choice for building scalable web applications.

## Why Next.js?

Next.js provides several features that make it ideal for building scalable applications:

1. **Server-side Rendering (SSR)**: Renders pages on the server, improving performance and SEO.
2. **Static Site Generation (SSG)**: Pre-renders pages at build time, providing the fastest possible loading experience.
3. **Incremental Static Regeneration (ISR)**: Updates static pages after deployment without rebuilding the entire site.
4. **API Routes**: Allows you to create serverless functions that can handle API requests.
5. **Automatic Code Splitting**: Only loads the JavaScript needed for each page.

## Best Practices for Scalability

### 1. Use the Right Rendering Strategy

Choose the appropriate rendering strategy based on your content:

- **Static Generation (SSG)**: For content that doesn't change frequently.
- **Server-side Rendering (SSR)**: For content that needs to be fresh on every request.
- **Incremental Static Regeneration (ISR)**: For content that changes occasionally.
- **Client-side Rendering**: For highly interactive components that don't need SEO.

### 2. Optimize Images

Use Next.js Image component to automatically optimize images:

\`\`\`jsx
import Image from 'next/image';

function MyComponent() {
  return (
    <Image
      src="/profile.jpg"
      alt="Profile"
      width={500}
      height={500}
      priority
    />
  );
}
\`\`\`

### 3. Implement Caching Strategies

Use caching headers to reduce server load and improve performance:

\`\`\`javascript
// In API routes
export default function handler(req, res) {
  res.setHeader('Cache-Control', 's-maxage=10, stale-while-revalidate=59');
  // Rest of your code
}
\`\`\`

### 4. Use Edge Functions for Global Performance

Deploy your Next.js application to the edge for faster global performance:

\`\`\`javascript
export const config = {
  runtime: 'experimental-edge',
};

export default function handler(req) {
  return new Response(JSON.stringify({ name: 'John Doe' }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
    },
  });
}
\`\`\`

## Conclusion

Next.js provides a robust foundation for building scalable web applications. By following these best practices, you can ensure your application performs well even as it grows to serve millions of users.
      `,
      date: "Mar 15, 2023",
      readTime: "8 min read",
      image: "/blog/nextjs-scaling.jpg",
      categories: ["Next.js", "Performance", "Architecture"],
      featured: true,
    },
    {
      id: "2",
      title: "The Future of React: What's Coming in React 19",
      slug: "future-of-react",
      excerpt: "Explore the upcoming features in React 19 and how they will change the way we build applications.",
      content: `
# The Future of React: What's Coming in React 19

React continues to evolve, and the upcoming React 19 release promises to bring exciting new features and improvements. Let's explore what's on the horizon and how these changes will impact the way we build applications.

## New Features in React 19

### 1. Improved Server Components

React Server Components are getting even better with enhanced data fetching capabilities and better integration with client components.

### 2. Compiler Optimizations

The React compiler is being improved to generate more efficient code, resulting in smaller bundle sizes and faster runtime performance.

### 3. Enhanced Suspense

Suspense is being expanded to support more use cases, making it easier to handle loading states and asynchronous operations.

### 4. New Hooks

Several new hooks are being introduced to simplify common patterns and reduce boilerplate code.

## How These Changes Will Impact Development

These new features will significantly change how we approach React development:

1. **More Server-First Thinking**: With improved server components, we'll need to think more about what can be rendered on the server versus the client.

2. **Better Performance by Default**: Compiler optimizations will make our applications faster without requiring manual optimizations.

3. **Simplified Async Handling**: Enhanced Suspense will make it easier to handle loading states and asynchronous operations.

4. **Reduced Boilerplate**: New hooks will simplify common patterns and reduce the amount of code we need to write.

## Preparing for React 19

To prepare for React 19, consider the following steps:

1. **Familiarize Yourself with Server Components**: Start using React Server Components in your current projects to understand their benefits and limitations.

2. **Adopt Suspense for Data Fetching**: Begin using Suspense for data fetching to get comfortable with the pattern.

3. **Stay Updated**: Follow the React team's blog and social media channels for the latest updates and announcements.

4. **Experiment with Canary Releases**: Try out canary releases to get early access to new features and provide feedback to the React team.

## Conclusion

React 19 promises to bring exciting improvements that will make our applications faster, more efficient, and easier to build. By staying informed and experimenting with new features early, we can be ready to take full advantage of these improvements when they're released.
      `,
      date: "Feb 28, 2023",
      readTime: "6 min read",
      image: "/blog/react-future.jpg",
      categories: ["React", "JavaScript", "Frontend"],
      featured: true,
    },
    {
      id: "3",
      title: "Optimizing Database Queries for Better Performance",
      slug: "optimizing-database-queries",
      excerpt: "Practical tips and techniques to improve your database queries and boost application performance.",
      content: `
# Optimizing Database Queries for Better Performance

Database performance is critical for application responsiveness. Slow queries can bottleneck your entire application, leading to poor user experience. In this article, we'll explore practical techniques to optimize database queries for better performance.

## Understanding Query Performance

Before optimizing, it's important to understand what makes a query slow:

1. **Missing Indexes**: Queries without proper indexes perform full table scans.
2. **Complex Joins**: Joining multiple tables can be expensive.
3. **Inefficient WHERE Clauses**: Poorly written conditions can prevent index usage.
4. **Retrieving Unnecessary Data**: Selecting more columns than needed increases I/O.

## Optimization Techniques

### 1. Use Proper Indexes

Indexes are crucial for query performance. They allow the database to find rows quickly without scanning the entire table.

\`\`\`sql
-- Create an index on the email column
CREATE INDEX idx_users_email ON users(email);

-- Query that will use the index
SELECT * FROM users WHERE email = 'user@example.com';
\`\`\`

### 2. Select Only Necessary Columns

Avoid using \`SELECT *\` and only retrieve the columns you need.

\`\`\`sql
-- Bad: Retrieves all columns
SELECT * FROM users WHERE status = 'active';

-- Good: Retrieves only necessary columns
SELECT id, name, email FROM users WHERE status = 'active';
\`\`\`

### 3. Optimize JOIN Operations

Use proper join types and ensure joined columns are indexed.

\`\`\`sql
-- Ensure both columns used in the JOIN are indexed
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_users_id ON users(id);

-- Efficient JOIN query
SELECT o.id, o.amount, u.name
FROM orders o
INNER JOIN users u ON o.user_id = u.id
WHERE o.status = 'completed';
\`\`\`

### 4. Use Query Caching

Implement caching for frequently executed queries that return the same results.

\`\`\`javascript
// Example using Redis for query caching
async function getUserById(id) {
  const cacheKey = \`user:\${id}\`;
  
  // Try to get from cache first
  const cachedUser = await redis.get(cacheKey);
  if (cachedUser) {
    return JSON.parse(cachedUser);
  }
  
  // If not in cache, query the database
  const user = await db.query('SELECT * FROM users WHERE id = ?', [id]);
  
  // Store in cache for future requests
  await redis.set(cacheKey, JSON.stringify(user), 'EX', 3600);
  
  return user;
}
\`\`\`

### 5. Use Database-Specific Optimization Tools

Most databases provide tools to analyze and optimize queries:

- MySQL: EXPLAIN
- PostgreSQL: EXPLAIN ANALYZE
- SQL Server: Query Execution Plan

\`\`\`sql
-- Example using EXPLAIN in MySQL
EXPLAIN SELECT * FROM users WHERE email = 'user@example.com';
\`\`\`

## Conclusion

Optimizing database queries is essential for application performance. By using proper indexes, selecting only necessary data, optimizing joins, implementing caching, and using database optimization tools, you can significantly improve query performance and enhance the overall user experience of your application.
      `,
      date: "Jan 20, 2023",
      readTime: "10 min read",
      image: "/blog/database-optimization.jpg",
      categories: ["Database", "Performance", "SQL"],
      featured: false,
    },
  ],

  photos: [
    {
      id: "1",
      title: "Coding Session",
      description: "Late night coding session working on a new project",
      image: "/gallery/coding1.jpg",
      date: "2023-03-15",
      categories: ["Coding", "Workspace"],
    },
    {
      id: "2",
      title: "Team Collaboration",
      description: "Brainstorming session with the development team",
      image: "/gallery/team1.jpg",
      date: "2023-02-20",
      categories: ["Team", "Collaboration"],
    },
    {
      id: "3",
      title: "Conference Talk",
      description: "Speaking at the annual Web Development Conference",
      image: "/gallery/conference1.jpg",
      date: "2023-01-10",
      categories: ["Conference", "Speaking"],
    },
    {
      id: "4",
      title: "Workspace Setup",
      description: "My productive workspace setup with dual monitors",
      image: "/gallery/workspace1.jpg",
      date: "2022-12-05",
      categories: ["Workspace", "Setup"],
    },
  ],

  videos: [
    {
      id: "1",
      title: "React Hooks Tutorial",
      description: "A comprehensive guide to using React Hooks in your applications",
      thumbnailImage: "/videos/thumbnails/react-hooks.jpg",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      date: "2023-03-10",
      categories: ["Tutorial", "React", "JavaScript"],
    },
    {
      id: "2",
      title: "Building a Next.js Application",
      description: "Step-by-step guide to building a full-stack application with Next.js",
      thumbnailImage: "/videos/thumbnails/nextjs-app.jpg",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      date: "2023-02-15",
      categories: ["Tutorial", "Next.js", "Full Stack"],
    },
    {
      id: "3",
      title: "Conference Talk: The Future of Web Development",
      description: "My talk at the annual Web Development Conference about upcoming trends",
      thumbnailImage: "/videos/thumbnails/conference-talk.jpg",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      date: "2023-01-20",
      categories: ["Conference", "Talk", "Web Development"],
    },
  ],

  testimonials: [
    {
      name: "John Smith",
      position: "CTO",
      company: "Tech Innovations Inc.",
      testimonial:
        "One of the most talented developers I've worked with. Delivered exceptional results on time and exceeded our expectations.",
      image: "/testimonials/john.jpg",
    },
    {
      name: "Sarah Johnson",
      position: "Product Manager",
      company: "Digital Solutions Ltd.",
      testimonial:
        "A pleasure to work with. Brings creative solutions to complex problems and communicates effectively throughout the project.",
      image: "/testimonials/sarah.jpg",
    },
    {
      name: "Michael Brown",
      position: "CEO",
      company: "StartUp Ventures",
      testimonial:
        "Transformed our idea into a beautiful, functional application. Highly recommended for any web development project.",
      image: "/testimonials/michael.jpg",
    },
  ],

  siteConfig: {
    title: "Your Name - Full Stack Developer",
    description:
      "Personal portfolio and blog of a passionate full stack developer specializing in React, Next.js, and Node.js.",
    themeColor: "#3b82f6", // Blue
    accentColor: "#8b5cf6", // Purple
    footerText: "Eat. Sleep. Code. Repeat.",
    showThemeToggle: true,
    showScrollToTop: true,
    blogEnabled: true,
    galleryEnabled: true,
    contactEnabled: true,
  },
}

export default portfolioData

