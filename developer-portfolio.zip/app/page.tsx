import Hero from "@/components/hero"
import About from "@/components/about"
import Skills from "@/components/skills"
import Experience from "@/components/experience"
import Education from "@/components/education"
import Achievements from "@/components/achievements"
import Blogs from "@/components/blogs"
import Contact from "@/components/contact"
import { Toaster } from "@/components/ui/toaster"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Toaster />
      <Hero />
      <About />
      <Skills />
      <Experience />
      <Education />
      <Achievements />
      <Blogs />
      <Contact />
    </main>
  )
}

