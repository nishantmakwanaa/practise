"use client"

import { motion } from "framer-motion"
import { Code, Database, Globe, Layout, Server, Smartphone, Terminal, Layers } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const skills = [
  {
    category: "Frontend Development",
    icon: <Layout className="h-10 w-10 text-purple-500" />,
    items: ["HTML5", "CSS3", "JavaScript", "TypeScript", "React", "Next.js", "Tailwind CSS", "Material UI", "Redux"],
  },
  {
    category: "Backend Development",
    icon: <Server className="h-10 w-10 text-blue-500" />,
    items: ["Node.js", "Express", "Python", "Django", "PHP", "Laravel", "RESTful APIs", "GraphQL"],
  },
  {
    category: "Database Management",
    icon: <Database className="h-10 w-10 text-green-500" />,
    items: ["MongoDB", "MySQL", "PostgreSQL", "Firebase", "Redis", "Prisma", "Sequelize"],
  },
  {
    category: "DevOps & Tools",
    icon: <Terminal className="h-10 w-10 text-red-500" />,
    items: ["Git", "GitHub", "Docker", "AWS", "Vercel", "CI/CD", "Jest", "Cypress"],
  },
  {
    category: "Mobile Development",
    icon: <Smartphone className="h-10 w-10 text-yellow-500" />,
    items: ["React Native", "Flutter", "Ionic", "Progressive Web Apps"],
  },
  {
    category: "Web Technologies",
    icon: <Globe className="h-10 w-10 text-cyan-500" />,
    items: ["RESTful Services", "WebSockets", "OAuth", "JWT", "HTTPS/SSL", "Web Performance"],
  },
  {
    category: "Programming Languages",
    icon: <Code className="h-10 w-10 text-indigo-500" />,
    items: ["JavaScript", "TypeScript", "Python", "PHP", "Java", "C#", "Go"],
  },
  {
    category: "UI/UX Design",
    icon: <Layers className="h-10 w-10 text-pink-500" />,
    items: ["Figma", "Adobe XD", "Sketch", "Responsive Design", "Wireframing", "Prototyping"],
  },
]

export default function Skills() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="skills" className="section-padding">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title gradient-text"
        >
          My Skills
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-center text-muted-foreground max-w-3xl mx-auto mb-12"
        >
          I've worked with a variety of technologies in the web development world. Here's a comprehensive list of my
          technical skills and expertise.
        </motion.p>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {skills.map((skill, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full overflow-hidden group hover:shadow-lg transition-shadow duration-300 border-t-4 hover:border-primary">
                <CardHeader className="pb-2">
                  <div className="mb-2">{skill.icon}</div>
                  <CardTitle className="font-poppins">{skill.category}</CardTitle>
                  <CardDescription>{skill.items.length} technologies</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skill.items.map((item, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-muted rounded-full text-xs font-medium group-hover:bg-primary/10 transition-colors"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

