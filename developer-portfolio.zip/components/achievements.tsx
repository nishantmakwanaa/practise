"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Award, Trophy, Star, BookOpen, Lightbulb, Users, Presentation, Zap } from "lucide-react"

const achievements = [
  {
    title: "Tech Innovation Award",
    organization: "Silicon Valley Tech Summit",
    year: "2023",
    description:
      "Recognized for developing an innovative AI-powered solution that revolutionized customer service automation.",
    icon: <Trophy className="h-10 w-10 text-yellow-500" />,
  },
  {
    title: "Open Source Contributor",
    organization: "GitHub",
    year: "2022",
    description:
      "Contributed to several major open-source projects with over 500+ commits and 20+ merged pull requests.",
    icon: <Star className="h-10 w-10 text-orange-500" />,
  },
  {
    title: "Published Research Paper",
    organization: "International Journal of Computer Science",
    year: "2021",
    description:
      "Published a research paper on 'Optimizing React Applications for Performance' that received widespread recognition.",
    icon: <BookOpen className="h-10 w-10 text-blue-500" />,
  },
  {
    title: "Patent for Web Technology",
    organization: "US Patent Office",
    year: "2021",
    description:
      "Received a patent for developing a novel approach to real-time data synchronization in web applications.",
    icon: <Lightbulb className="h-10 w-10 text-purple-500" />,
  },
  {
    title: "Hackathon Winner",
    organization: "Global Code Challenge",
    year: "2020",
    description:
      "Led a team of 4 developers to win first place in a 48-hour hackathon, building a solution for remote education.",
    icon: <Award className="h-10 w-10 text-red-500" />,
  },
  {
    title: "Tech Community Leader",
    organization: "Developer Meetup Group",
    year: "2019 - Present",
    description:
      "Founded and lead a community of 500+ developers, organizing monthly meetups and knowledge-sharing sessions.",
    icon: <Users className="h-10 w-10 text-green-500" />,
  },
  {
    title: "Conference Speaker",
    organization: "Multiple Tech Conferences",
    year: "2018 - Present",
    description:
      "Regular speaker at tech conferences, having delivered 15+ talks on web development, React, and performance optimization.",
    icon: <Presentation className="h-10 w-10 text-cyan-500" />,
  },
  {
    title: "Certified Solutions Architect",
    organization: "AWS",
    year: "2019",
    description: "Achieved AWS Certified Solutions Architect - Professional certification with a score in the top 10%.",
    icon: <Zap className="h-10 w-10 text-indigo-500" />,
  },
]

export default function Achievements() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="achievements" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title gradient-text"
        >
          Achievements
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-center text-muted-foreground max-w-3xl mx-auto mb-12"
        >
          Recognitions, awards, and milestones that highlight my contributions and expertise in the field of technology
          and development.
        </motion.p>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {achievements.map((achievement, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow duration-300 border-t-4 hover:border-primary">
                <CardHeader className="pb-2">
                  <div className="mb-2">{achievement.icon}</div>
                  <CardTitle className="font-poppins">{achievement.title}</CardTitle>
                  <CardDescription>
                    {achievement.organization} | {achievement.year}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{achievement.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

