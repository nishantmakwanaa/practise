"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Calendar, MapPin } from "lucide-react"

const educations = [
  {
    degree: "Master of Science in Computer Science",
    institution: "Stanford University",
    location: "Stanford, CA",
    period: "2016 - 2018",
    description:
      "Specialized in Artificial Intelligence and Machine Learning. Completed thesis on 'Neural Networks for Natural Language Processing'.",
    achievements: [
      "Graduated with Distinction (GPA: 3.9/4.0)",
      "Published 2 research papers in international conferences",
      "Teaching Assistant for 'Advanced Algorithms' course",
    ],
    courses: ["Advanced Algorithms", "Machine Learning", "Neural Networks", "Distributed Systems", "Cloud Computing"],
  },
  {
    degree: "Bachelor of Science in Computer Engineering",
    institution: "Massachusetts Institute of Technology",
    location: "Cambridge, MA",
    period: "2012 - 2016",
    description:
      "Comprehensive program covering both hardware and software aspects of computing systems. Minor in Mathematics.",
    achievements: [
      "Dean's List for all semesters",
      "Recipient of the Engineering Excellence Scholarship",
      "Participated in ACM Programming Contest",
    ],
    courses: ["Data Structures", "Computer Architecture", "Operating Systems", "Database Systems", "Web Development"],
  },
  {
    degree: "Full Stack Web Development Bootcamp",
    institution: "Coding Academy",
    location: "San Francisco, CA",
    period: "Summer 2015",
    description: "Intensive 12-week program focused on modern web development technologies and practices.",
    achievements: [
      "Developed a full-stack e-commerce application as capstone project",
      "Selected for mentorship program",
      "Won 'Best Project' award in final showcase",
    ],
    courses: ["JavaScript Fundamentals", "React", "Node.js", "MongoDB", "RESTful APIs"],
  },
]

export default function Education() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="education" className="section-padding">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title gradient-text"
        >
          Education
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-center text-muted-foreground max-w-3xl mx-auto mb-12"
        >
          My academic background and educational qualifications that have shaped my knowledge and expertise in the field
          of technology.
        </motion.p>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="space-y-8"
        >
          {educations.map((edu, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="overflow-hidden border-l-4 border-l-primary hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-2">
                    <div>
                      <CardTitle className="font-poppins text-xl md:text-2xl">{edu.degree}</CardTitle>
                      <CardDescription className="flex items-center mt-1">
                        <GraduationCap className="h-4 w-4 mr-1" />
                        {edu.institution}
                      </CardDescription>
                      <CardDescription className="flex items-center mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        {edu.location}
                      </CardDescription>
                    </div>
                    <Badge variant="outline" className="w-fit flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {edu.period}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{edu.description}</p>

                  <div>
                    <h4 className="font-semibold mb-2">Achievements:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                      {edu.achievements.map((achievement, i) => (
                        <li key={i}>{achievement}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Key Courses:</h4>
                    <div className="flex flex-wrap gap-2">
                      {edu.courses.map((course, i) => (
                        <span key={i} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                          {course}
                        </span>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

