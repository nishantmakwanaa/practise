"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, ArrowRight } from "lucide-react"

const blogPosts = [
  {
    title: "Building Scalable Web Applications with Next.js",
    excerpt: "Learn how to leverage Next.js features to build applications that can handle millions of users.",
    date: "Mar 15, 2023",
    readTime: "8 min read",
    image: "/placeholder.svg?height=400&width=600",
    categories: ["Next.js", "Performance", "Architecture"],
    slug: "building-scalable-web-applications",
  },
  {
    title: "The Future of React: What's Coming in React 19",
    excerpt: "Explore the upcoming features in React 19 and how they will change the way we build applications.",
    date: "Feb 28, 2023",
    readTime: "6 min read",
    image: "/placeholder.svg?height=400&width=600",
    categories: ["React", "JavaScript", "Frontend"],
    slug: "future-of-react",
  },
  {
    title: "Optimizing Database Queries for Better Performance",
    excerpt: "Practical tips and techniques to improve your database queries and boost application performance.",
    date: "Jan 20, 2023",
    readTime: "10 min read",
    image: "/placeholder.svg?height=400&width=600",
    categories: ["Database", "Performance", "SQL"],
    slug: "optimizing-database-queries",
  },
  {
    title: "Creating Accessible Web Applications: A Comprehensive Guide",
    excerpt: "Learn how to make your web applications accessible to everyone, including users with disabilities.",
    date: "Dec 12, 2022",
    readTime: "12 min read",
    image: "/placeholder.svg?height=400&width=600",
    categories: ["Accessibility", "HTML", "CSS"],
    slug: "creating-accessible-web-applications",
  },
  {
    title: "Implementing Authentication in Modern Web Applications",
    excerpt: "A step-by-step guide to implementing secure authentication in your web applications.",
    date: "Nov 5, 2022",
    readTime: "9 min read",
    image: "/placeholder.svg?height=400&width=600",
    categories: ["Security", "Authentication", "JWT"],
    slug: "implementing-authentication",
  },
  {
    title: "Mastering TypeScript: Advanced Types and Patterns",
    excerpt: "Take your TypeScript skills to the next level with advanced types, patterns, and best practices.",
    date: "Oct 18, 2022",
    readTime: "11 min read",
    image: "/placeholder.svg?height=400&width=600",
    categories: ["TypeScript", "JavaScript", "Programming"],
    slug: "mastering-typescript",
  },
]

export default function Blogs() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="blog" className="section-padding">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title gradient-text"
        >
          My Blog
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-center text-muted-foreground max-w-3xl mx-auto mb-12"
        >
          Sharing my knowledge, insights, and experiences in web development, programming, and technology through my
          blog articles.
        </motion.p>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {blogPosts.map((post, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <CardHeader className="pb-2">
                  <div className="flex flex-wrap gap-2 mb-2">
                    {post.categories.map((category, i) => (
                      <Badge key={i} variant="secondary" className="font-normal">
                        {category}
                      </Badge>
                    ))}
                  </div>
                  <CardTitle className="font-poppins text-xl hover:text-primary transition-colors">
                    <Link href={`/blog/${post.slug}`}>{post.title}</Link>
                  </CardTitle>
                  <CardDescription className="flex items-center gap-4 text-xs">
                    <span className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {post.date}
                    </span>
                    <span className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {post.readTime}
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground">{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="p-0 h-auto" asChild>
                    <Link href={`/blog/${post.slug}`} className="flex items-center text-primary hover:underline">
                      Read More <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true }}
          className="flex justify-center mt-12"
        >
          <Button asChild size="lg">
            <Link href="/blog">View All Posts</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

