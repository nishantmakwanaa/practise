"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="about" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title gradient-text"
        >
          About Me
        </motion.h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative w-full h-[400px] md:h-[500px] mx-auto">
              <div className="absolute -inset-4 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-xl blur-xl"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl opacity-30"></div>
              <div className="relative h-full w-full overflow-hidden rounded-xl border border-purple-500/20">
                <video autoPlay loop muted playsInline className="h-full w-full object-cover">
                  <source
                    src="https://assets.mixkit.co/videos/preview/mixkit-programming-a-code-in-a-computer-screen-close-up-shot-28592-large.mp4"
                    type="video/mp4"
                  />
                  Your browser does not support the video tag.
                </video>
              </div>
            </div>
          </motion.div>

          <motion.div ref={ref} variants={containerVariants} initial="hidden" animate={isInView ? "visible" : "hidden"}>
            <motion.h3 variants={itemVariants} className="text-2xl md:text-3xl font-bold mb-4 font-poppins">
              I'm <span className="text-primary">Your Name</span>, a Full Stack Developer
            </motion.h3>

            <motion.p variants={itemVariants} className="mb-4 text-muted-foreground">
              With over 5 years of experience in web development, I specialize in creating responsive, user-friendly
              applications using modern technologies. My passion lies in solving complex problems and delivering
              exceptional user experiences.
            </motion.p>

            <motion.p variants={itemVariants} className="mb-6 text-muted-foreground">
              I have a strong foundation in both front-end and back-end development, with expertise in React, Next.js,
              Node.js, and database management. I'm constantly learning and adapting to new technologies to stay at the
              forefront of web development.
            </motion.p>

            <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <h4 className="font-semibold mb-2">Name:</h4>
                <p className="text-muted-foreground">Your Name</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Email:</h4>
                <p className="text-muted-foreground">your.email@example.com</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Phone:</h4>
                <p className="text-muted-foreground">+1 (123) 456-7890</p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Location:</h4>
                <p className="text-muted-foreground">San Francisco, CA</p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Button className="rounded-full" size="lg">
                <Download className="mr-2 h-4 w-4" /> Download CV
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

