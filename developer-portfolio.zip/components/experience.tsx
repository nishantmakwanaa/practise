"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Briefcase, Calendar } from "lucide-react"

const experiences = [
  {
    title: "Senior Full Stack Developer",
    company: "Tech Innovations Inc.",
    period: "Jan 2022 - Present",
    description:
      "Leading the development of enterprise-level web applications using Next.js, React, and Node.js. Implementing CI/CD pipelines and mentoring junior developers.",
    achievements: [
      "Reduced application load time by 40% through performance optimizations",
      "Implemented a microservices architecture that improved scalability",
      "Led a team of 5 developers to deliver projects on time and within budget",
    ],
    technologies: ["React", "Next.js", "Node.js", "TypeScript", "AWS", "Docker"],
  },
  {
    title: "Full Stack Developer",
    company: "Digital Solutions Ltd.",
    period: "Mar 2020 - Dec 2021",
    description:
      "Developed and maintained multiple client websites and web applications. Collaborated with designers and product managers to deliver high-quality solutions.",
    achievements: [
      "Built a custom e-commerce platform that increased client sales by 25%",
      "Implemented responsive designs that improved mobile user engagement by 30%",
      "Optimized database queries resulting in 50% faster data retrieval",
    ],
    technologies: ["JavaScript", "React", "Express", "MongoDB", "PostgreSQL", "Redux"],
  },
  {
    title: "Frontend Developer",
    company: "Creative Web Agency",
    period: "Jun 2018 - Feb 2020",
    description:
      "Created responsive and interactive user interfaces for various client websites. Worked closely with the design team to implement pixel-perfect designs.",
    achievements: [
      "Developed a component library that reduced development time by 20%",
      "Implemented accessibility improvements that achieved WCAG AA compliance",
      "Created interactive data visualizations for client dashboards",
    ],
    technologies: ["HTML5", "CSS3", "JavaScript", "React", "Sass", "Webpack"],
  },
  {
    title: "Web Development Intern",
    company: "StartUp Ventures",
    period: "Jan 2018 - May 2018",
    description:
      "Assisted in the development of web applications and learned industry best practices. Participated in code reviews and agile development processes.",
    achievements: [
      "Developed a feature that was included in the production application",
      "Created documentation for the onboarding process for future interns",
      "Participated in user testing and bug fixing",
    ],
    technologies: ["HTML", "CSS", "JavaScript", "jQuery", "Bootstrap"],
  },
]

export default function Experience() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="experience" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title gradient-text"
        >
          Work Experience
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-center text-muted-foreground max-w-3xl mx-auto mb-12"
        >
          My professional journey in the tech industry, showcasing my growth and contributions to various projects and
          organizations.
        </motion.p>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="space-y-8"
        >
          {experiences.map((exp, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="overflow-hidden border-l-4 border-l-primary hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-2">
                    <div>
                      <CardTitle className="font-poppins text-xl md:text-2xl">{exp.title}</CardTitle>
                      <CardDescription className="flex items-center mt-1">
                        <Briefcase className="h-4 w-4 mr-1" />
                        {exp.company}
                      </CardDescription>
                    </div>
                    <Badge variant="outline" className="w-fit flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {exp.period}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{exp.description}</p>

                  <div>
                    <h4 className="font-semibold mb-2">Key Achievements:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                      {exp.achievements.map((achievement, i) => (
                        <li key={i}>{achievement}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-2">
                    {exp.technologies.map((tech, i) => (
                      <span key={i} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                        {tech}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

