import mysql from "mysql2/promise"

// Database connection configuration
const dbConfig = {
  host: process.env.MYSQL_HOST || "localhost",
  user: process.env.MYSQL_USER || "root",
  password: process.env.MYSQL_PASSWORD || "",
  database: process.env.MYSQL_DATABASE || "portfolio",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
}

// Create a connection pool
const pool = mysql.createPool(dbConfig)

// Helper function to execute SQL queries
export async function query(sql: string, params: any[] = []) {
  try {
    const [results] = await pool.execute(sql, params)
    return results
  } catch (error) {
    console.error("Database query error:", error)
    throw error
  }
}

// Initialize database tables if they don't exist
export async function initDatabase() {
  try {
    // Create users table
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create blog_comments table
    await query(`
      CREATE TABLE IF NOT EXISTS blog_comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        blog_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create blog_likes table
    await query(`
      CREATE TABLE IF NOT EXISTS blog_likes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        blog_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY blog_user_unique (blog_id, user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create photo_comments table
    await query(`
      CREATE TABLE IF NOT EXISTS photo_comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        photo_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create photo_likes table
    await query(`
      CREATE TABLE IF NOT EXISTS photo_likes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        photo_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY photo_user_unique (photo_id, user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create video_comments table
    await query(`
      CREATE TABLE IF NOT EXISTS video_comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        video_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create video_likes table
    await query(`
      CREATE TABLE IF NOT EXISTS video_likes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        video_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY video_user_unique (video_id, user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    console.log("Database tables initialized successfully")
  } catch (error) {
    console.error("Error initializing database:", error)
    throw error
  }
}

// Blog related functions
export async function getBlogComments(blogId: string) {
  return await query(
    `
    SELECT c.*, u.name, u.image 
    FROM blog_comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.blog_id = ?
    ORDER BY c.created_at DESC
  `,
    [blogId],
  )
}

export async function addBlogComment(blogId: string, userId: string, content: string) {
  return await query(
    `
    INSERT INTO blog_comments (blog_id, user_id, content)
    VALUES (?, ?, ?)
  `,
    [blogId, userId, content],
  )
}

export async function getBlogLikes(blogId: string) {
  return await query(
    `
    SELECT COUNT(*) as count
    FROM blog_likes
    WHERE blog_id = ?
  `,
    [blogId],
  )
}

export async function toggleBlogLike(blogId: string, userId: string) {
  // Check if like exists
  const [existingLike] = (await query(
    `
    SELECT id FROM blog_likes
    WHERE blog_id = ? AND user_id = ?
  `,
    [blogId, userId],
  )) as any[]

  if (existingLike) {
    // Unlike
    await query(
      `
      DELETE FROM blog_likes
      WHERE blog_id = ? AND user_id = ?
    `,
      [blogId, userId],
    )
    return { action: "unliked" }
  } else {
    // Like
    await query(
      `
      INSERT INTO blog_likes (blog_id, user_id)
      VALUES (?, ?)
    `,
      [blogId, userId],
    )
    return { action: "liked" }
  }
}

// Photo related functions
export async function getPhotoComments(photoId: string) {
  return await query(
    `
    SELECT c.*, u.name, u.image 
    FROM photo_comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.photo_id = ?
    ORDER BY c.created_at DESC
  `,
    [photoId],
  )
}

export async function addPhotoComment(photoId: string, userId: string, content: string) {
  return await query(
    `
    INSERT INTO photo_comments (photo_id, user_id, content)
    VALUES (?, ?, ?)
  `,
    [photoId, userId, content],
  )
}

export async function getPhotoLikes(photoId: string) {
  return await query(
    `
    SELECT COUNT(*) as count
    FROM photo_likes
    WHERE photo_id = ?
  `,
    [photoId],
  )
}

export async function togglePhotoLike(photoId: string, userId: string) {
  // Check if like exists
  const [existingLike] = (await query(
    `
    SELECT id FROM photo_likes
    WHERE photo_id = ? AND user_id = ?
  `,
    [photoId, userId],
  )) as any[]

  if (existingLike) {
    // Unlike
    await query(
      `
      DELETE FROM photo_likes
      WHERE photo_id = ? AND user_id = ?
    `,
      [photoId, userId],
    )
    return { action: "unliked" }
  } else {
    // Like
    await query(
      `
      INSERT INTO photo_likes (photo_id, user_id)
      VALUES (?, ?)
    `,
      [photoId, userId],
    )
    return { action: "liked" }
  }
}

// Video related functions
export async function getVideoComments(videoId: string) {
  return await query(
    `
    SELECT c.*, u.name, u.image 
    FROM video_comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.video_id = ?
    ORDER BY c.created_at DESC
  `,
    [videoId],
  )
}

export async function addVideoComment(videoId: string, userId: string, content: string) {
  return await query(
    `
    INSERT INTO video_comments (video_id, user_id, content)
    VALUES (?, ?, ?)
  `,
    [videoId, userId, content],
  )
}

export async function getVideoLikes(videoId: string) {
  return await query(
    `
    SELECT COUNT(*) as count
    FROM video_likes
    WHERE video_id = ?
  `,
    [videoId],
  )
}

export async function toggleVideoLike(videoId: string, userId: string) {
  // Check if like exists
  const [existingLike] = (await query(
    `
    SELECT id FROM video_likes
    WHERE video_id = ? AND user_id = ?
  `,
    [videoId, userId],
  )) as any[]

  if (existingLike) {
    // Unlike
    await query(
      `
      DELETE FROM video_likes
      WHERE video_id = ? AND user_id = ?
    `,
      [videoId, userId],
    )
    return { action: "unliked" }
  } else {
    // Like
    await query(
      `
      INSERT INTO video_likes (video_id, user_id)
      VALUES (?, ?)
    `,
      [videoId, userId],
    )
    return { action: "liked" }
  }
}

// User related functions
export async function createOrUpdateUser(user: { id: string; name: string; email: string; image?: string }) {
  return await query(
    `
    INSERT INTO users (id, name, email, image)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    email = VALUES(email),
    image = VALUES(image)
  `,
    [user.id, user.name, user.email, user.image || null],
  )
}

export async function getUserById(id: string) {
  const [user] = (await query(
    `
    SELECT * FROM users WHERE id = ?
  `,
    [id],
  )) as any[]

  return user
}

